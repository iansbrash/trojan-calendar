var AWS = require("aws-sdk");
AWS.config.update({
    region: "us-east-1",
});

const {
    DynamoDBClient
} = require('@aws-sdk/client-dynamodb');

exports.handler = async (event) => {
    // TODO implement
    const response = {
        statusCode: 200,
        body:  JSON.stringify(event) //JSON.stringify(event),
    };
    
    const claims = event.requestContext.authorizer.claims;
    
    const userId = claims['cognito:username'];
    
    
    let res2 = {
        statusCode: 200,
        body: JSON.stringify(userId),
        headers: {
            'Access-Control-Allow-Origin': '*'
        }
    }
    
    console.log(`userId: ${userId}`)
    
    const params = {
        TableName: 'trojandashUserData',
        Key:
        {
            "userId": {
                S: userId
            },
        }
    }
    
    let result = await DynamoDBClient.getItem(params).promise();
    
    res2.body = JSON.stringify(result)
    
    return res2;
};
